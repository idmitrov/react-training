import React, { Component } from 'react';
import Switch from './switch';

export default class App extends Component{
  render() {
    return(
      <div>
        <Switch />
      </div>
    );
  }
}