# ReactJS
Training build base 

## Requements
 - nodejs 4.4
 
## First run & Development
You need to install all additional node packages
```sh
$ npm install -g webpack
$ npm install -g webpack-dev-server
$ npm install

```
Start environments: 
```sh
$ npm start
```